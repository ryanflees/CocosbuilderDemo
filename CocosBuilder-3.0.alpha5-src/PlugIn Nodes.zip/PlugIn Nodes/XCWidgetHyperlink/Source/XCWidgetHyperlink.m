/*
 * CocosBuilder: http://www.cocosbuilder.com
 *
 * Copyright (c) 2012 Zynga Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#import "XCWidgetHyperlink.h"

#define XCWH_PRESSED_COLOR4F	ccc4f(1.f,1.f,0.f,1.f)
#define XCWH_UNPRESSED_COLOR4F	ccc4f(0.f,1.f,0.f,1.f)
#define XCWH_PRESSED_COLOR3		ccc3(0xff,0xff,0x0)
#define XCWH_UNPRESSED_COLOR3	ccc3(0x0,0xff,0x0)

@implementation XCWidgetHyperlink


- (id) init
{
    self = [super init];
    if (!self) return NULL;
    
    label = [[[CCLabelTTF alloc] init] autorelease];
    label.fontSize = 35;
    [self addChild:label z:1];
    label.anchorPoint = ccp(0.5f, 0.5f);
    label.position = ccp(0, 0);
    
    return self;
}

-(void) dealloc
{
    [super dealloc];
}

-(void) setString:(NSString*)var
{
    [label setString:var];
    [self updateTextureRect];
}

-(NSString*) getString
{
    return label.string;
}

-(void) setFontSize:(float) size
{
    label.fontSize = size;
    [self updateTextureRect];
}

-(float) getFontSize
{
    return label.fontSize;
}

-(void) updateTextureRect
{
    label.color = XCWH_UNPRESSED_COLOR3;
}

@end
